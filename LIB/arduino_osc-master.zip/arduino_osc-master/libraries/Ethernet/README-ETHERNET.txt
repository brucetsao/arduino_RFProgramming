These files augment the Ethernet library as distributed with Arduino0012, which in turn appears to include
application sample code from WIZnet. Eventually, we'll have to modify the underlying socket code of that library to fix buffer overflow risks and to better conserve precious Arduino RAM.

For more information, look at:
http://code.rancidbacon.com/LearningAboutArduinoWIZ810MJ
http://trac.mlalonde.net/cral/browser/branches/follower/wiz810mj
12/31/08